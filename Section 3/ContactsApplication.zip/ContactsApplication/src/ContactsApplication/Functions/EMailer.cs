﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using DataLayer.Model;
using Newtonsoft.Json;

namespace ContactsApplication.Functions
{
    public class EMailer
    {
        public static void SendContactAdded(ContactData contactData)
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post,
                @"https://contactsemail.azurewebsites.net/api/SendContactAdded?code=p6s816DBoC0N/bbD19q394h9F3ldvSCUL8EsDtg9K7efkreDXodcDQ==");
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            request.Content = new StringContent(JsonConvert.SerializeObject(new
            {
                from = "noreply@contacts.com",
                to = "danbailey1000@msn.com",
                subject = string.Format("Added Contact {0},{1}", contactData.FirstName, contactData.LastName)
            }), Encoding.UTF8,
                "application/json");
            var response = client.SendAsync(request).Result;
            if (!response.IsSuccessStatusCode)
            {
                var content = response.Content.ReadAsStringAsync().Result;
                throw new Exception("SendContactAdded Failed " + content);
            }
        }
    }
}
