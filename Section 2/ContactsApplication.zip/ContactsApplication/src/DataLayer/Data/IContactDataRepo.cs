﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataLayer.Model;

namespace DataLayer.Data
{
    /// <summary>
    /// Interface for data repository
    /// </summary>
    public interface IContactRepo
    {
        IEnumerable<ContactData> Get();
        ContactData Get(int id);
        void Add(ContactData contactData);
        void Update(int id, ContactData contactData);
        void Delete(int id);
    }
}
