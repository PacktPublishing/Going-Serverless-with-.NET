﻿using System.Collections.Generic;
using DataLayer.Data;
using DataLayer.Model;
using Microsoft.AspNetCore.Mvc;

namespace ContactsApplication.Controllers
{
    [Route("api/[controller]")]
    public class ContactsController : Controller
    {
        private readonly IContactRepo _contactRepo = new AzureTableClient
        {
            AccessKey = "5IdtUOefCaulTce0CWsaYzMPvwFIkfLZGffoOR2jylBH9FALVrqYsYEd4rMdZUZ9kkvXE6FsxT7xNnODH+HTQQ==",
            StorageAccount = "contactsstorage1",
            TableName = "Contacts"
        };

        // GET api/contacts
        [HttpGet]
        public IEnumerable<ContactData> Get()
        {
            return _contactRepo.Get();
        }

        // GET api/contacts/5
        [HttpGet("{id}")]
        public ContactData Get(int id)
        {
            return _contactRepo.Get(id);
        }

        // POST api/contacts
        [HttpPost]
        public void Post([FromBody] ContactData contactData)
        {
            _contactRepo.Add(contactData);
        }

        // PUT api/contacts/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] ContactData contactData)
        {
            _contactRepo.Update(id, contactData);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _contactRepo.Delete(id);
        }
    }
}
